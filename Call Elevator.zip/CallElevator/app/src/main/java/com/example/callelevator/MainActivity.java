package com.example.callelevator;

import androidx.appcompat.app.AppCompatActivity;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Iterator;

public class MainActivity extends AppCompatActivity {

    Button fstflr;
    Button sndflr;
    Button thirdflr;
    Button forthflr;
    Button fthflr;
    Button sixflr;
    Button svnflr;
    Button eigflr;

    TextView textDeviceName;

    //USB
    //ID of "Arduino" (or any other device): Receiving devices
    //To allow the phone sending command to the receiving device.
    //To allocate the ID, you may use the USB Serial Terminal by mightIT.
    private static final int targetVendorID = 6790;
    private static final int targetProductID = 29987;
    UsbDevice deviceFound = null;
    UsbInterface usbInterfaceFound = null;
    UsbEndpoint endpointIn = null;
    UsbEndpoint endpointOut = null;
    private static final String ACTION_USB_PERMISSION =
            "com.android.example.USB_PERMISSION";
    PendingIntent mPermissionIntent;

    UsbInterface usbInterface;
    UsbDeviceConnection usbDeviceConnection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fstflr = findViewById(R.id.FirstFloor);
        sndflr = findViewById(R.id.SecondFloor);
        thirdflr = findViewById(R.id.ThirdFloor);
        forthflr = findViewById(R.id.ForthFloor);
        fthflr = findViewById(R.id.FifthFloor);
        sixflr = findViewById(R.id.SixthFloor);
        svnflr = findViewById(R.id.SeventhFloor);
        eigflr = findViewById(R.id.EighthFloor);

        //Displaying the device name
        textDeviceName = (TextView) findViewById(R.id.textdevicename);

        //register the broadcast receiver
        mPermissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(ACTION_USB_PERMISSION), PendingIntent.FLAG_IMMUTABLE);
        IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
        registerReceiver(mUsbReceiver, filter);

        registerReceiver(mUsbDeviceReceiver, new IntentFilter(UsbManager.ACTION_USB_DEVICE_ATTACHED));
        registerReceiver(mUsbDeviceReceiver, new IntentFilter(UsbManager.ACTION_USB_DEVICE_DETACHED));

        connectUsb();


    }

    //Unregister the USB when it disconnected for security concern. Some sort of termination
    @Override
    protected void onDestroy() {
        releaseUsb();
        unregisterReceiver(mUsbReceiver);
        unregisterReceiver(mUsbDeviceReceiver);
        super.onDestroy();
    }

    //USB is disconnected
    private void releaseUsb() {

        Toast.makeText(MainActivity.this, "USB is disconnected", Toast.LENGTH_LONG).show();

        if (usbDeviceConnection != null) {
            if (usbInterface != null) {
                usbDeviceConnection.releaseInterface(usbInterface);
                usbInterface = null;
            }
            usbDeviceConnection.close();
            usbDeviceConnection = null;
        }

        deviceFound = null;
        usbInterfaceFound = null;
        endpointIn = null;
        endpointOut = null;
    }

    //Toast the message when USB is connected
    private void connectUsb() {
        searchEndPoint();
        Toast.makeText(MainActivity.this, "USB is connected", Toast.LENGTH_LONG).show();
        Toast.makeText(MainActivity.this, "End point searched", Toast.LENGTH_LONG).show();
        if (usbInterfaceFound != null) {
            setupUsbComm();
            Toast.makeText(MainActivity.this, "Communication Setup", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(MainActivity.this, "End point is null", Toast.LENGTH_LONG).show();
        }
    }

    private void searchEndPoint() {

        usbInterfaceFound = null;
        endpointOut = null;
        endpointIn = null;

        //Search device for targetVendorID and targetProductID
        if (deviceFound == null) {
            UsbManager manager = (UsbManager) getSystemService(Context.USB_SERVICE);
            HashMap<String, UsbDevice> deviceList = manager.getDeviceList();
            Iterator<UsbDevice> deviceIterator = deviceList.values().iterator();

            while (deviceIterator.hasNext()) {
                UsbDevice device = deviceIterator.next();

                if (device.getVendorId() == targetVendorID) {
                    if (device.getProductId() == targetProductID) {
                        deviceFound = device;
                    }
                }
            }
        }

        if (deviceFound == null) {
            Toast.makeText(MainActivity.this, "Device not found, check if cable fault or other matters", Toast.LENGTH_LONG).show();
            Toast.makeText(MainActivity.this, "Not targeted device", Toast.LENGTH_LONG).show();
        } else {

            //Search for UsbInterface with Endpoint of USB_ENDPOINT_XFER_BULK,
            //and direction USB_DIR_OUT and USB_DIR_IN

            for (int i = 0; i < deviceFound.getInterfaceCount(); i++) {
                UsbInterface usbif = deviceFound.getInterface(i);

                UsbEndpoint tOut = null;
                UsbEndpoint tIn = null;

                int tEndpointCnt = usbif.getEndpointCount();
                if (tEndpointCnt >= 2) {
                    for (int j = 0; j < tEndpointCnt; j++) {
                        if (usbif.getEndpoint(j).getType() ==
                                UsbConstants.USB_ENDPOINT_XFER_BULK) {
                            if (usbif.getEndpoint(j).getDirection() ==
                                    UsbConstants.USB_DIR_OUT) {
                                tOut = usbif.getEndpoint(j);
                            } else if (usbif.getEndpoint(j).getDirection() ==
                                    UsbConstants.USB_DIR_IN) {
                                tIn = usbif.getEndpoint(j);
                            }
                        }
                    }

                    if (tOut != null && tIn != null) {
                        //This interface have both USB_DIR_OUT
                        //and USB_DIR_IN of USB_ENDPOINT_XFER_BULK
                        usbInterfaceFound = usbif;
                        endpointOut = tOut;
                        endpointIn = tIn;
                    }
                }

            }


        }
    }

    private boolean setupUsbComm() {

        //for more info, search SET_LINE_CODING and
        //SET_CONTROL_LINE_STATE in the document:
        //"Universal Serial Bus Class Definitions for Communication Devices"
        //at http://adf.ly/dppFt
        final int RQSID_SET_LINE_CODING = 0x20;
        final int RQSID_SET_CONTROL_LINE_STATE = 0x22;

        boolean success = false;

        UsbManager manager = (UsbManager) getSystemService(Context.USB_SERVICE);
        Boolean permitToRead = manager.hasPermission(deviceFound);

        Toast.makeText(MainActivity.this, "Permission: " + permitToRead.toString(), Toast.LENGTH_LONG).show();

        if (permitToRead) {
            usbDeviceConnection = manager.openDevice(deviceFound);
            if (usbDeviceConnection != null) {
                usbDeviceConnection.claimInterface(usbInterfaceFound, true);

                //showRawDescriptors(); //skip it if you no need show RawDescriptors

                final int[] usbResult = new int[1];
                usbResult[0] = usbDeviceConnection.controlTransfer(
                        0x21,        //requestType
                        RQSID_SET_CONTROL_LINE_STATE, //SET_CONTROL_LINE_STATE
                        0,     //value
                        0,     //index
                        null,    //buffer
                        0,     //length
                        0);    //timeout


                //baud rate = 9600
                //8 data bit
                //1 stop bit
                byte[] encodingSetting =
                        new byte[]{(byte) 0x80, 0x25, 0x00, 0x00, 0x00, 0x00, 0x08};
                usbResult[0] = usbDeviceConnection.controlTransfer(
                        0x21,       //requestType
                        RQSID_SET_LINE_CODING,   //SET_LINE_CODING
                        0,      //value
                        0,      //index
                        encodingSetting,  //buffer
                        7,      //length
                        0);     //timeout


                fstflr.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        byte[] bytesCallFstFlr = new byte[]{(byte) 0x01}; //Calling Third Floor
                        usbResult[0] = usbDeviceConnection.bulkTransfer(
                                endpointOut,
                                bytesCallFstFlr,
                                bytesCallFstFlr.length,
                                0);

                        Toast.makeText(MainActivity.this, "Calling 1st Floor", Toast.LENGTH_LONG).show();

                    }
                });

                sndflr.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        byte[] bytesCallSndFlr = new byte[]{(byte) 0x02}; //Calling Third Floor
                        usbResult[0] = usbDeviceConnection.bulkTransfer(
                                endpointOut,
                                bytesCallSndFlr,
                                bytesCallSndFlr.length,
                                0);

                        Toast.makeText(MainActivity.this, "Calling 2nd Floor", Toast.LENGTH_LONG).show();

                    }
                });


                thirdflr.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        byte[] bytesCallThirdFlr = new byte[]{(byte) 0x03}; //Calling Third Floor
                        usbResult[0] = usbDeviceConnection.bulkTransfer(
                                endpointOut,
                                bytesCallThirdFlr,
                                bytesCallThirdFlr.length,
                                0);

                        Toast.makeText(MainActivity.this, "Calling 3rd Floor", Toast.LENGTH_LONG).show();

                    }
                });

                forthflr.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        byte[] bytesCallThirdFlr = new byte[]{(byte) 0x04}; //Calling Third Floor
                        usbResult[0] = usbDeviceConnection.bulkTransfer(
                                endpointOut,
                                bytesCallThirdFlr,
                                bytesCallThirdFlr.length,
                                0);

                        Toast.makeText(MainActivity.this, "Calling 4th Floor", Toast.LENGTH_LONG).show();

                    }
                });

                fthflr.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        byte[] bytesCallFifthFlr = new byte[]{(byte) 0x05}; //Calling Third Floor
                        usbResult[0] = usbDeviceConnection.bulkTransfer(
                                endpointOut,
                                bytesCallFifthFlr,
                                bytesCallFifthFlr.length,
                                0);

                        Toast.makeText(MainActivity.this, "Calling 5th Floor", Toast.LENGTH_LONG).show();

                    }
                });

                sixflr.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        byte[] bytesCallSixthFlr = new byte[]{(byte) 0x06}; //Calling Third Floor
                        usbResult[0] = usbDeviceConnection.bulkTransfer(
                                endpointOut,
                                bytesCallSixthFlr,
                                bytesCallSixthFlr.length,
                                0);

                        Toast.makeText(MainActivity.this, "Calling 6th Floor", Toast.LENGTH_LONG).show();

                    }
                });

                svnflr.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        byte[] bytesCallSvnFlr = new byte[]{(byte) 0x07}; //Calling Third Floor
                        usbResult[0] = usbDeviceConnection.bulkTransfer(
                                endpointOut,
                                bytesCallSvnFlr,
                                bytesCallSvnFlr.length,
                                0);

                        Toast.makeText(MainActivity.this, "Calling 7th Floor", Toast.LENGTH_LONG).show();

                    }
                });

                eigflr.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        byte[] bytesCallEigFlr = new byte[]{(byte) 0x08}; //Calling Third Floor
                        usbResult[0] = usbDeviceConnection.bulkTransfer(
                                endpointOut,
                                bytesCallEigFlr,
                                bytesCallEigFlr.length,
                                0);

                        Toast.makeText(MainActivity.this, "Calling 8th Floor", Toast.LENGTH_LONG).show();

                    }
                });


            }

        } else {
            manager.requestPermission(deviceFound, mPermissionIntent);
            Toast.makeText(MainActivity.this, "Permission denied", Toast.LENGTH_LONG).show();
        }


        return success;
    }

    private final BroadcastReceiver mUsbReceiver =
            new BroadcastReceiver() {

                @Override
                public void onReceive(Context context, Intent intent) {
                    String action = intent.getAction();
                    if (ACTION_USB_PERMISSION.equals(action)) {


                        synchronized (this) {
                            UsbDevice device = (UsbDevice) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);

                            if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                                if (device != null) {
                                    connectUsb();
                                }
                            } else {
//                                Toast.makeText(MainActivity.this, "Permission denied for device", Toast.LENGTH_LONG).show();

                            }
                        }
                    }
                }
            };

    private final BroadcastReceiver mUsbDeviceReceiver =
            new BroadcastReceiver() {

                @Override
                public void onReceive(Context context, Intent intent) {
                    String action = intent.getAction();
                    if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(action)) {

                        deviceFound = (UsbDevice) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                        connectUsb();

                    } else if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {

                        UsbDevice device = (UsbDevice) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);

                        if (device != null) {
                            if (device == deviceFound) {
                                releaseUsb();
                            }
                        }
                    }
                }

            };


}